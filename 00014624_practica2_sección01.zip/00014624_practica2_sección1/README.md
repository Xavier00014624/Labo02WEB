# Práctica 2 - Programación Web UCA

Contenido ajustado para que siga exactamente el ejemplo mostrado en la guía PDF.

Estructura principal:
- ejercicio1/ (index.html + index.css)  <- actualizado para coincidir con el PDF (HTML y selectores de ejemplo)
- ejercicio2/ (index.html + index.css)
- ejercicio3/ (index.html + index.css)
- ejercicio4/ (index.html + index.css + imagenes/)

Se revisaron los enlaces a los archivos CSS para usar `index.css` (coherente con la guía).
